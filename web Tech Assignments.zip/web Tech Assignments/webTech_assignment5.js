var express=require('express');
var mysql=require('mysql');
var app=express();
var bodyParser=require('body-parser');




app.use(bodyParser.json());



var connection =mysql.createConnection({

host:'localhost',
port:'3306',
user:'root',
password:'',
database:'emps',
multipleStatements:true
});



connection.connect(function(err){
    if (err){console.log("Connection Failed!!" + err);}
    else{console.log("Connection Successful!");}
});


app.get('/students',(req,res)=>{
    connection.query('SELECT * FROM STUDENTS',(err,rows,fields)=>{
        if(!err)
        res.send(rows);
        else
        console.log(err);
    })
});

app.get('/delStudents',(req,res)=>{
    connection.query('DELETE  FROM STUDENTS WHERE ID=?',[req.query.ID],(err,rows,fields)=>{
        if(!err)
        res.send('Deleted Data Successfully with ID:'+req.query.ID);
        else
        console.log(err);
    })
});


app.get('/addStudents',(req,res)=>{
    let data ={ID:req.query.ID,F_name:req.query.F_name,L_name:req.query.L_name};
    
    let sql ="INSERT INTO Students SET ?";
    connection.query(sql,data,(err,rows,fields)=>{
        if(!err)
        res.send(rows);
        else
        console.log(err);
    })
});

app.get('/updateStudents',(req,res)=>{
    var v_ID=req.query.newID;
    var v_F_name=req.query.F_name;
    var v_L_name=req.query.L_name;
    var oldID=req.query.ID;
    let sql ="UPDATE students set ID="+v_ID+", F_name='"+v_F_name+"', L_name='"+v_L_name+"' where ID ="+oldID+"";
    //const request=new sql.Request();
    connection.query(sql,(err,rows,fields)=>{
        if(!err)
        res.send(rows);
        else
        console.log(err);
    })
});


var server = app.listen(8081, function() {
	var port = server.address().port
	var host = server.address().address
	console.log("Server is listening on: http://%s:%s", host, port)
})