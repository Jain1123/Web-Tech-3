// Name: Sakshi Jain ; Student ID: c0753352
var express = require('express');
var app = express();
var cors = require('cors');
var bodyParser = require('body-parser')
app.use(cors());
app.use(bodyParser.json());


movie_db = [{"Rental_ID": "444", "Customer_Name" : "Sakshi", "Movie_Name" : "3 Idiots", "Movie_Length":"2hours", "Rent_Price" : "20", "Days": "1"},
			   {"Rental_ID": "333", "Customer_Name" : "Jain", "Movie_Name" : "The croods", "Movie_Length":"3hours", "Rent_Price" : "25", "Days": "2"}];
console.log(movie_db);

app.get('/display', function(req, res){
	var result = "";
	for(i = 0;i<movie_db.length;i++){
		
		result += "Rental ID: " + movie_db[i].Rental_ID +
				  "<br>Customer Name: " + movie_db[i].Customer_Name +
				  "<br>Movie Name: " + movie_db[i].Movie_Name +
				  "<br>Movie Length: " + movie_db[i].Movie_Length +
				  "<br>Rental Price: " + movie_db[i].Rent_Price +
				  "<br>Number of Days: " + movie_db[i].Days +
				  "<br>================================<br>";
	}
	res.send(result);
	
	res.write('<body bgColor="yellow">');
        res.write('<table bgColor="linkColor" border="5px"><tr>');
        res.write('<tr>');
				res.write('<th>Rental ID</th><th>Customer Name</th><th>Movie Name</th><th>Movie Length</th><th>Rental Price</th><th>Number of Days</th>');
				res.write('</tr>')
        for (var row in result){
			
            res.write('<tr>');
            for (var column in result[row]){
				
                res.write('<td>'+result[row][column]+'</td>');
            }
            
			res.write('</tr>');
        }
		
        res.end('</table>');
		res.end('</body>');
		res.send(result);
})

//===========================================================

app.get('/addData', function(req, res){
	
	
	res.end("Adding Movie Rental ID: " + req.query.Rental_ID + "Customer Name: " + req.query.Customer_Name + " Movie Name: " +
	req.query.Movie_Name + " Movie Length: " + req.query.Movie_Length + "Rental Price: "+ req.query.Rent_Price + "Number of Days: "+ req.query.Days);
	var movie_obj = {
		Rental_ID: req.query.Rental_ID,
		Customer_Name:  req.query.Customer_Name,
		Movie_Name:         req.query.Movie_Name,
		Movie_Length:  req.query.Movie_Length,
		Rent_Price : req.query.Rent_Price,
		Days: req.query.Days
	};
	movie_db.push(movie_obj);
	
	
	
})

//=============================================



var server = app.listen(8081, function() {
	var port = server.address().port
	var host = server.address().address
	console.log("Server is listening on: http://%s:%s", host, port)
})





